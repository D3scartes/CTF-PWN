#!/bin/bash

cd /home/user && ./chall